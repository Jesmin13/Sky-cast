import React, { useEffect, useRef } from 'react';
import { StyleSheet, Animated, Easing, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { skyPalettes } from '../theme';

const { width, height } = Dimensions.get('window');

// The signature element of the app: a full-bleed gradient built from the
// current condition + time of day, with a slow-drifting orb (sun/moon) and
// two cloud silhouettes that cross the screen on independent loops. Nothing
// here is decorative for its own sake — the orb's height on screen roughly
// tracks how high the sun actually is (dawn/dusk = low, midday = high).

export default function BackgroundSky({ paletteKey = 'day_clear', isDay = true, orbHeight = 0.3 }) {
  const drift1 = useRef(new Animated.Value(0)).current;
  const drift2 = useRef(new Animated.Value(0)).current;
  const glow = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(drift1, {
        toValue: 1,
        duration: 42000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();
    Animated.loop(
      Animated.timing(drift2, {
        toValue: 1,
        duration: 65000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(glow, { toValue: 1, duration: 3200, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(glow, { toValue: 0.6, duration: 3200, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const cloud1X = drift1.interpolate({ inputRange: [0, 1], outputRange: [-160, width + 160] });
  const cloud2X = drift2.interpolate({ inputRange: [0, 1], outputRange: [width + 200, -200] });

  const colorStops = skyPalettes[paletteKey] || skyPalettes.day_clear;
  const orbColor = isDay ? '#FFE9C6' : '#EAF1FF';
  const orbTop = height * (1 - orbHeight) * 0.55;

  return (
    <Animated.View style={StyleSheet.absoluteFill} pointerEvents="none">
      <LinearGradient
        colors={colorStops}
        start={{ x: 0.15, y: 0 }}
        end={{ x: 0.85, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <Animated.View
        style={[
          styles.orb,
          {
            top: orbTop,
            backgroundColor: orbColor,
            opacity: glow,
            shadowColor: orbColor,
          },
        ]}
      />
      <Animated.View style={[styles.cloud, { top: height * 0.18, transform: [{ translateX: cloud1X }] }]} />
      <Animated.View style={[styles.cloud, styles.cloudSmall, { top: height * 0.3, transform: [{ translateX: cloud2X }] }]} />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  orb: {
    position: 'absolute',
    alignSelf: 'center',
    width: 120,
    height: 120,
    borderRadius: 60,
    shadowOpacity: 0.9,
    shadowRadius: 40,
    elevation: 10,
  },
  cloud: {
    position: 'absolute',
    width: 140,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  cloudSmall: {
    width: 90,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.10)',
  },
});
