import React, { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, type, space, radius } from '../theme';
import { getWeatherInfo } from '../utils/weatherCodes';

const DAY_FMT = new Intl.DateTimeFormat('en-US', { weekday: 'short' });

export default function DailyForecast({ daily }) {
  const { minAll, maxAll } = useMemo(() => {
    if (!daily) return { minAll: 0, maxAll: 1 };
    return {
      minAll: Math.min(...daily.temperature_2m_min),
      maxAll: Math.max(...daily.temperature_2m_max),
    };
  }, [daily]);

  if (!daily) return null;
  const span = Math.max(1, maxAll - minAll);

  return (
    <View style={styles.section}>
      <Text style={styles.heading}>7-day forecast</Text>
      <View style={styles.card}>
        {daily.time.map((iso, i) => {
          const date = new Date(iso);
          const label = i === 0 ? 'Today' : DAY_FMT.format(date);
          const code = daily.weather_code[i];
          const { icon } = getWeatherInfo(code, true);
          const lo = daily.temperature_2m_min[i];
          const hi = daily.temperature_2m_max[i];
          const leftPct = ((lo - minAll) / span) * 100;
          const widthPct = Math.max(8, ((hi - lo) / span) * 100);

          return (
            <View key={iso} style={[styles.row, i === daily.time.length - 1 && { borderBottomWidth: 0 }]}>
              <Text style={styles.day}>{label}</Text>
              <Ionicons name={icon} size={20} color={colors.text} style={styles.rowIcon} />
              <Text style={styles.pop}>{daily.precipitation_probability_max?.[i] ?? 0}%</Text>
              <Text style={styles.lo}>{Math.round(lo)}°</Text>
              <View style={styles.barTrack}>
                <View style={[styles.barFill, { left: `${leftPct}%`, width: `${widthPct}%` }]} />
              </View>
              <Text style={styles.hi}>{Math.round(hi)}°</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  section: { marginTop: space.xl, marginBottom: space.xxl },
  heading: {
    color: colors.textDim,
    fontFamily: type.body,
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    marginLeft: space.lg,
    marginBottom: space.sm,
  },
  card: {
    marginHorizontal: space.lg,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    borderRadius: radius.lg,
    paddingHorizontal: space.md,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.cardBorder,
  },
  day: { color: colors.text, fontFamily: type.body, fontSize: 14, width: 56 },
  rowIcon: { width: 26 },
  pop: { color: colors.textDim, fontFamily: type.mono, fontSize: 11, width: 34 },
  lo: { color: colors.textFaint, fontFamily: type.mono, fontSize: 13, width: 30, textAlign: 'right' },
  hi: { color: colors.text, fontFamily: type.monoMedium, fontSize: 13, width: 34, textAlign: 'right' },
  barTrack: {
    flex: 1,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.14)',
    marginHorizontal: space.sm,
    overflow: 'hidden',
  },
  barFill: {
    position: 'absolute',
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.accent,
  },
});
