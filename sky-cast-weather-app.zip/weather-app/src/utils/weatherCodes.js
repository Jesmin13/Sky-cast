// Open-Meteo returns WMO weather codes (integers). This maps each code to
// a human description, an Ionicons name, and which sky palette to use.
// https://open-meteo.com/en/docs (see "WMO Weather interpretation codes")

const TABLE = {
  0:  { desc: 'Clear sky',            icon: 'sunny',          paletteDay: 'day_clear',  paletteNight: 'night_clear' },
  1:  { desc: 'Mainly clear',         icon: 'partly-sunny',   paletteDay: 'day_clear',  paletteNight: 'night_clear' },
  2:  { desc: 'Partly cloudy',        icon: 'partly-sunny',   paletteDay: 'day_cloudy', paletteNight: 'night_cloudy' },
  3:  { desc: 'Overcast',             icon: 'cloudy',         paletteDay: 'overcast',   paletteNight: 'night_cloudy' },
  45: { desc: 'Fog',                  icon: 'reorder-four',   paletteDay: 'fog',        paletteNight: 'fog' },
  48: { desc: 'Depositing rime fog',  icon: 'reorder-four',   paletteDay: 'fog',        paletteNight: 'fog' },
  51: { desc: 'Light drizzle',        icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  53: { desc: 'Drizzle',              icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  55: { desc: 'Dense drizzle',        icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  56: { desc: 'Freezing drizzle',     icon: 'rainy',          paletteDay: 'snow',       paletteNight: 'snow' },
  57: { desc: 'Dense freezing drizzle', icon: 'rainy',        paletteDay: 'snow',       paletteNight: 'snow' },
  61: { desc: 'Slight rain',          icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  63: { desc: 'Rain',                 icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  65: { desc: 'Heavy rain',           icon: 'rainy',          paletteDay: 'storm',      paletteNight: 'storm' },
  66: { desc: 'Freezing rain',        icon: 'rainy',          paletteDay: 'snow',       paletteNight: 'snow' },
  67: { desc: 'Heavy freezing rain',  icon: 'rainy',          paletteDay: 'snow',       paletteNight: 'snow' },
  71: { desc: 'Slight snow fall',     icon: 'snow',           paletteDay: 'snow',       paletteNight: 'snow' },
  73: { desc: 'Snow fall',            icon: 'snow',           paletteDay: 'snow',       paletteNight: 'snow' },
  75: { desc: 'Heavy snow fall',      icon: 'snow',           paletteDay: 'snow',       paletteNight: 'snow' },
  77: { desc: 'Snow grains',          icon: 'snow',           paletteDay: 'snow',       paletteNight: 'snow' },
  80: { desc: 'Slight rain showers',  icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  81: { desc: 'Rain showers',         icon: 'rainy',          paletteDay: 'rain',       paletteNight: 'rain' },
  82: { desc: 'Violent rain showers', icon: 'thunderstorm',   paletteDay: 'storm',      paletteNight: 'storm' },
  85: { desc: 'Slight snow showers',  icon: 'snow',           paletteDay: 'snow',       paletteNight: 'snow' },
  86: { desc: 'Heavy snow showers',   icon: 'snow',           paletteDay: 'snow',       paletteNight: 'snow' },
  95: { desc: 'Thunderstorm',         icon: 'thunderstorm',   paletteDay: 'storm',      paletteNight: 'storm' },
  96: { desc: 'Thunderstorm w/ hail', icon: 'thunderstorm',   paletteDay: 'storm',      paletteNight: 'storm' },
  99: { desc: 'Severe thunderstorm w/ hail', icon: 'thunderstorm', paletteDay: 'storm', paletteNight: 'storm' },
};

export function getWeatherInfo(code, isDay = true) {
  const entry = TABLE[code] || TABLE[3];
  return {
    description: entry.desc,
    icon: entry.icon,
    paletteKey: isDay ? entry.paletteDay : entry.paletteNight,
  };
}

// For dawn/dusk override — called by the caller when sun angle is near
// sunrise/sunset regardless of what Open-Meteo's is_day flag says.
export function twilightPaletteKey(isSunrise) {
  return isSunrise ? 'dawn' : 'dusk';
}
