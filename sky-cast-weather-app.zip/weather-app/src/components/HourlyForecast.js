import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, type, space, radius } from '../theme';
import { getWeatherInfo } from '../utils/weatherCodes';

export default function HourlyForecast({ hourly, currentIsoHour }) {
  if (!hourly) return null;

  const startIdx = Math.max(0, hourly.time.findIndex((t) => t === currentIsoHour));
  const slice = hourly.time.slice(startIdx, startIdx + 24);

  return (
    <View style={styles.section}>
      <Text style={styles.heading}>Hourly forecast</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
        {slice.map((iso, i) => {
          const idx = startIdx + i;
          const hour = new Date(iso).getHours();
          const label = i === 0 ? 'Now' : `${hour % 12 === 0 ? 12 : hour % 12}${hour < 12 ? 'am' : 'pm'}`;
          const code = hourly.weather_code[idx];
          const { icon } = getWeatherInfo(code, hour >= 6 && hour < 19);
          return (
            <View key={iso} style={styles.card}>
              <Text style={styles.hourLabel}>{label}</Text>
              <Ionicons name={icon} size={22} color={colors.text} style={{ marginVertical: 8 }} />
              <Text style={styles.hourTemp}>{Math.round(hourly.temperature_2m[idx])}°</Text>
              <Text style={styles.hourPop}>{hourly.precipitation_probability?.[idx] ?? 0}%</Text>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  section: { marginTop: space.xl },
  heading: {
    color: colors.textDim,
    fontFamily: type.body,
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
    marginLeft: space.lg,
    marginBottom: space.sm,
  },
  row: { paddingHorizontal: space.lg, gap: space.sm },
  card: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    borderRadius: radius.md,
    width: 62,
    paddingVertical: space.sm,
    alignItems: 'center',
  },
  hourLabel: { color: colors.textDim, fontFamily: type.mono, fontSize: 11 },
  hourTemp: { color: colors.text, fontFamily: type.monoMedium, fontSize: 15 },
  hourPop: { color: colors.textFaint, fontFamily: type.mono, fontSize: 10, marginTop: 2 },
});
