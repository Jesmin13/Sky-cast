// Design tokens for Sky Cast.
// The signature idea: the whole screen's palette is derived from two real
// inputs — time of day and current condition — not a fixed brand color.
// So the app looks different at 7am in fog vs 9pm in a clear sky.

export const skyPalettes = {
  dawn:        ['#2B2145', '#7A4C6B', '#FF9E72'],
  day_clear:   ['#2E6FB3', '#4FA6D9', '#BFE6F7'],
  day_cloudy:  ['#5C7182', '#8CA0AE', '#D3DCE1'],
  overcast:    ['#41505C', '#6B7C89', '#A7B4BC'],
  rain:        ['#232C33', '#3D4E58', '#5B6E79'],
  storm:       ['#14181F', '#2A2F3A', '#454C58'],
  snow:        ['#4A6478', '#8FAABD', '#E8F1F6'],
  dusk:        ['#241B3D', '#6B3F63', '#E08752'],
  night_clear: ['#060A18', '#111C36', '#233252'],
  night_cloudy:['#0D0F14', '#1C2027', '#2E333C'],
  fog:         ['#4E5459', '#7B8288', '#B7BCC0'],
};

export const colors = {
  text: '#F6F8FA',
  textDim: 'rgba(246,248,250,0.68)',
  textFaint: 'rgba(246,248,250,0.4)',
  card: 'rgba(255,255,255,0.10)',
  cardBorder: 'rgba(255,255,255,0.16)',
  accent: '#FFC796', // warm sun accent, used sparingly (selected day, highlights)
  danger: '#FF8A80',
};

export const type = {
  display: 'SpaceGrotesk_700Bold',   // big temperature numbers
  displayMedium: 'SpaceGrotesk_500Medium',
  body: 'System',                     // condition text, labels
  mono: 'JetBrainsMono_400Regular',   // hourly/daily data rows — instrument-panel feel
  monoMedium: 'JetBrainsMono_500Medium',
};

export const space = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 10,
  md: 18,
  lg: 28,
  pill: 999,
};
