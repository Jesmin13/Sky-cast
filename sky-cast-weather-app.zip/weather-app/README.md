# Sky Cast

A React Native (Expo) weather app. Live data from [Open-Meteo](https://open-meteo.com/) —
no API key or account needed.

## Features

- Current conditions: temperature, feels-like, humidity, wind, UV index, precipitation
- 24-hour scrollable forecast strip
- 7-day forecast with min/max temperature bars
- City search with autocomplete (Open-Meteo geocoding)
- "Use my location" button (expo-location)
- Background gradient + sun/moon position that respond to the real sunrise/sunset
  and current condition for the selected city (dawn, day, dusk, night, rain, storm,
  snow, fog all have distinct looks)
- Pull-to-refresh

## Setup

You'll need [Node.js](https://nodejs.org/) and the Expo Go app on your phone
(or an iOS/Android simulator).

```bash
cd weather-app
npm install
npx expo start
```

Then either:
- Scan the QR code with the **Expo Go** app on your phone, or
- Press `i` for the iOS simulator / `a` for the Android emulator.

## Project structure

```
weather-app/
├── App.js                      # Screen composition, location, data fetching
├── app.json                    # Expo config (name, permissions)
├── src/
│   ├── theme.js                 # Color palettes, type scale, spacing tokens
│   ├── api/weather.js           # Open-Meteo fetch + geocoding calls
│   ├── utils/weatherCodes.js    # WMO weather code → description/icon/palette
│   └── components/
│       ├── BackgroundSky.js     # Animated gradient sky + drifting sun/clouds
│       ├── SearchBar.js         # City search with debounced autocomplete
│       ├── CurrentWeather.js    # Hero temperature + stat row
│       ├── HourlyForecast.js    # Horizontal 24h strip
│       └── DailyForecast.js     # 7-day list with hi/lo range bars
```

## Notes on the API

Open-Meteo is free and requires no key, but it does have fair-use rate limits
for high-volume production use — see their [docs](https://open-meteo.com/en/docs)
if you plan to ship this widely. Swapping in a different provider (e.g.
OpenWeatherMap) only requires editing `src/api/weather.js` and the field
names read off `data.current` / `data.daily` / `data.hourly` in `App.js`.

## Permissions

Location access is optional — if denied, the app falls back to New York and
you can still search any city manually.
