import React, { useState, useRef, useCallback } from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity, FlatList, Text, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, type, radius, space } from '../theme';
import { searchPlaces } from '../api/weather';

export default function SearchBar({ onSelectPlace, onUseLocation, locating }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef(null);

  const runSearch = useCallback((text) => {
    setQuery(text);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (text.trim().length < 2) {
      setResults([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      try {
        setLoading(true);
        const places = await searchPlaces(text);
        setResults(places);
      } catch {
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 350);
  }, []);

  const handleSelect = (place) => {
    setQuery('');
    setResults([]);
    onSelectPlace(place);
  };

  return (
    <View style={styles.wrap}>
      <View style={styles.inputRow}>
        <Ionicons name="search" size={18} color={colors.textDim} style={{ marginRight: space.sm }} />
        <TextInput
          value={query}
          onChangeText={runSearch}
          placeholder="Search a city"
          placeholderTextColor={colors.textFaint}
          style={styles.input}
          autoCorrect={false}
          returnKeyType="search"
        />
        {loading && <ActivityIndicator size="small" color={colors.textDim} />}
        <TouchableOpacity onPress={onUseLocation} style={styles.locateBtn} disabled={locating}>
          {locating ? (
            <ActivityIndicator size="small" color={colors.text} />
          ) : (
            <Ionicons name="locate" size={18} color={colors.text} />
          )}
        </TouchableOpacity>
      </View>

      {results.length > 0 && (
        <View style={styles.dropdown}>
          <FlatList
            data={results}
            keyExtractor={(item) => item.id}
            keyboardShouldPersistTaps="handled"
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.resultRow} onPress={() => handleSelect(item)}>
                <Text style={styles.resultName}>{item.name}</Text>
                <Text style={styles.resultSub}>
                  {[item.admin1, item.country].filter(Boolean).join(', ')}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingHorizontal: space.lg, zIndex: 20 },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    borderRadius: radius.pill,
    paddingHorizontal: space.md,
    height: 46,
  },
  input: {
    flex: 1,
    color: colors.text,
    fontFamily: type.body,
    fontSize: 16,
  },
  locateBtn: {
    marginLeft: space.sm,
    padding: space.xs,
  },
  dropdown: {
    marginTop: space.sm,
    backgroundColor: 'rgba(20,24,31,0.92)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    maxHeight: 260,
    overflow: 'hidden',
  },
  resultRow: {
    paddingVertical: 10,
    paddingHorizontal: space.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.cardBorder,
  },
  resultName: { color: colors.text, fontFamily: type.body, fontSize: 15, fontWeight: '600' },
  resultSub: { color: colors.textDim, fontFamily: type.body, fontSize: 12, marginTop: 2 },
});
