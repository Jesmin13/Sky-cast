import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, type, space, radius } from '../theme';

function Stat({ icon, label, value }) {
  return (
    <View style={styles.stat}>
      <Ionicons name={icon} size={16} color={colors.textDim} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

export default function CurrentWeather({ placeName, current, todayHigh, todayLow, icon, description }) {
  if (!current) return null;
  const temp = Math.round(current.temperature_2m);
  const feelsLike = Math.round(current.apparent_temperature);

  return (
    <View style={styles.wrap}>
      <Text style={styles.place} numberOfLines={1}>{placeName}</Text>

      <View style={styles.heroRow}>
        <Ionicons name={icon} size={64} color={colors.text} style={{ marginRight: space.md }} />
        <Text style={styles.temp}>{temp}°</Text>
      </View>

      <Text style={styles.desc}>{description}</Text>
      <Text style={styles.hiLo}>
        H:{Math.round(todayHigh)}°  L:{Math.round(todayLow)}°  ·  Feels like {feelsLike}°
      </Text>

      <View style={styles.statCard}>
        <Stat icon="water-outline" label="Humidity" value={`${Math.round(current.relative_humidity_2m)}%`} />
        <View style={styles.divider} />
        <Stat icon="speedometer-outline" label="Wind" value={`${Math.round(current.wind_speed_10m)} km/h`} />
        <View style={styles.divider} />
        <Stat icon="sunny-outline" label="UV Index" value={`${Math.round(current.uv_index ?? 0)}`} />
        <View style={styles.divider} />
        <Stat icon="rainy-outline" label="Precip." value={`${current.precipitation ?? 0} mm`} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingHorizontal: space.lg, alignItems: 'center', marginTop: space.md },
  place: { color: colors.text, fontFamily: type.body, fontSize: 20, fontWeight: '600' },
  heroRow: { flexDirection: 'row', alignItems: 'center', marginTop: space.sm },
  temp: { color: colors.text, fontFamily: type.display, fontSize: 88, lineHeight: 92 },
  desc: { color: colors.text, fontFamily: type.body, fontSize: 17, marginTop: 2, textTransform: 'capitalize' },
  hiLo: { color: colors.textDim, fontFamily: type.mono, fontSize: 13, marginTop: 6 },
  statCard: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.cardBorder,
    borderRadius: radius.lg,
    marginTop: space.lg,
    paddingVertical: space.md,
    width: '100%',
    justifyContent: 'space-between',
  },
  stat: { flex: 1, alignItems: 'center', gap: 4 },
  statValue: { color: colors.text, fontFamily: type.monoMedium, fontSize: 15, marginTop: 2 },
  statLabel: { color: colors.textFaint, fontFamily: type.body, fontSize: 11 },
  divider: { width: StyleSheet.hairlineWidth, backgroundColor: colors.cardBorder, marginVertical: 4 },
});
